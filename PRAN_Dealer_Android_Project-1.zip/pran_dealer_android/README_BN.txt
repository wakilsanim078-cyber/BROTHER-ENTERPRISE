PRAN DEALER ANDROID APP - SETUP GUIDE
=====================================

এই ফোল্ডারটি Android Studio project source। এটি এখনো APK নয়। এই পরিবেশে Android SDK/Gradle build tools নেই, তাই APK compile করা যায়নি।

A. Firebase Cloud Sync চালু করুন
--------------------------------
1. https://console.firebase.google.com এ গিয়ে নতুন Firebase project তৈরি করুন।
2. Authentication > Sign-in method থেকে Email/Password enable করুন।
3. Firestore Database তৈরি করুন (Production mode) এবং firestore.rules ফাইলের rules Publish করুন।
4. Project settings > General > Your apps > Web app তৈরি করে Firebase config কপি করুন।
5. app/src/main/assets/index.html ফাইলে নিচের firebaseConfig object-এ নিজের মান বসান:
   apiKey, authDomain, projectId, appId
6. Firebase Authentication থেকে Owner-এর email/password account তৈরি করুন।
7. Firestore > users collection-এ Owner-এর Authentication UID নামে document তৈরি করুন। Fields:
   name: "Owner"
   email: "your-owner-email@example.com"
   role: "owner"
   target: 700000

B. SR account তৈরি
------------------
1. Owner অ্যাপে Login করবেন।
2. SR Management > নতুন SR যোগ করুন। SR-এর নাম, email, monthly target দিন।
3. SR নিজের ফোনে অ্যাপ খুলে SR Account Register চাপবে এবং Owner দেওয়া একই email দিয়ে password তৈরি করবে।
4. Invite মিললে SR profile স্বয়ংক্রিয়ভাবে তৈরি হবে। এরপর Login করবে।

C. APK build করুন
-----------------
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio > Open > এই pran_dealer_android ফোল্ডারটি নির্বাচন করুন।
3. Gradle sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
4. APK পাওয়া যাবে: app/build/outputs/apk/debug/app-debug.apk
5. APK ফোনে পাঠিয়ে Install করুন। প্রয়োজনে Android-এ এই ফাইলের জন্য Install unknown apps অনুমতি দিন।

D. গুরুত্বপূর্ণ সীমাবদ্ধতা
------------------------
- Cloud sync-এর জন্য Firebase project/config এবং internet প্রয়োজন।
- এটি প্রাথমিক Sales + SR management build। আপনার আগের চাহিদার গাড়ি/পণ্যভিত্তিক stock, খরচ, প্রাপ্য/প্রদেয়, salary, profit-loss module এখনো যোগ করা হয়নি।
- Firebase security rules publish না করে live business data ব্যবহার করবেন না।
- Owner-এর প্রথম profile হাতে তৈরি করতে হয়; password কারও সঙ্গে শেয়ার করবেন না।
